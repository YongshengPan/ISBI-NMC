function imdb = ad_get_database(dataDir, varargin)

rng(0, 'twister') ;
opts.seed = 0 ;
opts.imgsc = 'MRI' ;
opts = vl_argparse(opts, varargin) ;

imdb.imageDir = fullfile(dataDir, '') ;
annos1 = load(fullfile(dataDir,'ADNI1SubjectLabels.mat'));
annos2 = load(fullfile(dataDir,'ADNI2SubjectLabels.mat'));

imdb.classes.name = {'AD', 'MCI', 'NC'};
imdb.images.label = annos1.SubjectLabelID(:,2)'+1;
imdb.images.id    = annos1.SubjectLabelID(:,1)';
imdb.images.set   = 1*ones(1,length(annos1.SubjectLabelID));

start= 0.9;
for idx = 1:3
    num = sum(imdb.images.label==idx);
    imdb.images.set(imdb.images.label == idx) = [1*ones(1,round(num*start)), 3*ones(1,num-round(num*start)-round(num*(0.9-start))), 1*ones(1,round(num*(0.9-start)))];
end
imdb.images.set(annos1.SubjectLabelID(:,4)==0) = 0;

switch opts.imgsc
    case 'MRI'
        imdb.images.name  = [strcat('/MRI/ADNI1_', cellfun(@(S)num2str(S),num2cell(annos1.SubjectLabelID(:,3)),'UniformOutput', false), '_99_MRI.jpg');...
            strcat('/MRI/ADNI2_', cellfun(@(S)num2str(S),num2cell(annos2.SubjectLabelID(:,3)), 'UniformOutput', false), '_99_MRI.jpg')];
    case 'PET'
        imdb.images.name  = [strcat('/PET/ADNI1_', cellfun(@(S)num2str(S),num2cell(annos1.SubjectLabelID(:,3)),'UniformOutput', false), '_99_PET.jpg');...
            strcat('/PET/ADNI2_', cellfun(@(S)num2str(S),num2cell(annos2.SubjectLabelID(:,3)), 'UniformOutput', false), '_99_PET.jpg')];
end



imdb.maskDir = fullfile(dataDir, 'mask') ;



imdb.segments = imdb.images ;
imdb.segments.imageId = imdb.images.id ;
imdb.segments.mask = strrep(imdb.images.name, 'image', 'mask') ;

% make this compatible with the OS imdb
imdb.meta.classes = imdb.classes.name ;
imdb.meta.inUse = true(1,numel(imdb.meta.classes)) ;
imdb.segments.difficult = false(1, numel(imdb.segments.id)) ;


