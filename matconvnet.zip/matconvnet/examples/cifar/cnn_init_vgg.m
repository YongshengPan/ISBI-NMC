function net = cnn_init_vgg(varargin)
opts.networkType = 'dagnn' ;
opts = vl_argparse(opts, varargin) ;


% abs/1312.4400, 2013.

modelPath = fullfile(vl_rootnn, '..','data//models//imagenet-caffe-alex.mat');

net = load(modelPath);
% Meta parameters
net.meta.inputSize = [224 224 3];
net.meta.trainOpts.learningRate = [0.0002 * ones(1,20), 0.001 * ones(1,20), 0.0005 * ones(1,40), 0.00025 * ones(1,20)];
net.meta.trainOpts.weightDecay = 0.0005 ;
net.meta.trainOpts.batchSize = 1;
net.meta.trainOpts.numEpochs = numel(net.meta.trainOpts.learningRate) ;

% Switch to DagNN if requested
net = dagnn.DagNN.fromSimpleNN(net) ;
%     addLayer(obj, name, block, inputs, outputs, params, varargin)
net.addLayer('loss', dagnn.Loss('loss', 'log'), ...
    {'x21','label'}, 'objective') ;
% net.addLayer('dropout', dagnn.DropOut('rate', 0.5), 'objective', 'lalala') ;

net.addLayer('error', dagnn.Loss('loss', 'classerror'), ...
    {'x21','label'}, 'error') ;
