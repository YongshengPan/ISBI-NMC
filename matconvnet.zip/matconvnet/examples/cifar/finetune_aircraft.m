function [net, info] = finetune_aircraft(varargin)
% CNN_CIFAR   Demonstrates MatConvNet on CIFAR-10
%    The demo includes two standard model: LeNet and Network in
%    Network (NIN). Use the 'modelType' option to choose one.

run(fullfile(fileparts(mfilename('fullpath')), ...
  '..', '..', 'matlab', 'vl_setupnn.m')) ;

rootPath = fullfile(vl_rootnn, '..') ;
opts.modelType = 'res' ;
[opts, varargin] = vl_argparse(opts, varargin) ;

opts.expDir = fullfile(rootPath, 'data/exp03-02/aircraft-seed-01', ...
  sprintf('fintuning-%s', opts.modelType)) ;
[opts, varargin] = vl_argparse(opts, varargin) ;

opts.dataDir = fullfile(rootPath, 'data','cifar') ;
opts.imdbPath = fullfile(rootPath, 'data/exp03-02/aircraft-seed-01', 'imdb/imdb-seed-1.mat');
opts.whitenData = true ;
opts.contrastNormalization = true ;
opts.networkType = 'dagnn' ;
opts.train = struct('gpus', 1) ;
opts = vl_argparse(opts, varargin) ;
if ~isfield(opts.train, 'gpus'), opts.train.gpus = []; end;

% -------------------------------------------------------------------------
%                                                    Prepare model and data
% -------------------------------------------------------------------------

switch opts.modelType
    case 'res'
        net = cnn_init_res('networkType', opts.networkType) ;
    case 'vgg'
        net = cnn_init_vgg('networkType', opts.networkType) ;
end

if exist(opts.imdbPath, 'file')
  imdb = load(opts.imdbPath) ;
else
  imdb = getCifarImdb(opts) ;
  mkdir(opts.expDir) ;
  save(opts.imdbPath, '-struct', 'imdb') ;
end

net.meta.classes.name = imdb.meta.classes(:)' ;

% -------------------------------------------------------------------------
%                                                                     Train
% -------------------------------------------------------------------------

switch opts.networkType
  case 'simplenn', trainfn = @cnn_train ;
  case 'dagnn', trainfn = @cnn_train_dag ;
end

[net, info] = trainfn(net, imdb, getBatch(opts), ...
  'expDir', opts.expDir, ...
  net.meta.trainOpts, ...
  opts.train, ...
  'train', find(imdb.images.set == 1 | imdb.images.set == 2),...
  'val', find(imdb.images.set == 3)) ;

% -------------------------------------------------------------------------
function fn = getBatch(opts)
% -------------------------------------------------------------------------
switch lower(opts.networkType)
  case 'simplenn'
    fn = @(x,y) getSimpleNNBatch(x,y) ;
  case 'dagnn'
    bopts = struct('numGpus', numel(opts.train.gpus)) ;
    fn = @(x,y) getDagNNBatch(bopts,x,y) ;
end

% -------------------------------------------------------------------------
function [images, labels] = getSimpleNNBatch(imdb, batch)
% -------------------------------------------------------------------------
images = imdb.images.data(:,:,:,batch) ;
labels = imdb.images.labels(1,batch) ;
if rand > 0.5, images=fliplr(images) ; end

% -------------------------------------------------------------------------
function inputs = getDagNNBatch(opts, imdb, batch)
% -------------------------------------------------------------------------
% imfiles = cellfun(@(fn) fullfile(vl_rootnn, imdb.imageDir, fn), imdb.images.name(batch), 'UniformOutput', false);
imfiles = fullfile(vl_rootnn, imdb.imageDir, imdb.images.name(batch));


if ismember(imdb.images.set(batch(1)),[1, 2])
    if opts.numGpus > 0
        images = vl_imreadjpeg(imfiles, 'Resize', [224, 224], 'Pack', 'CropLocation', 'random', 'CropSize',[0.25, 1], 'GPU', 'Flip', 'NumThreads', 12);
    else
        images = vl_imreadjpeg(imfiles, 'Resize', [224, 224], 'Pack', 'CropLocation', 'random', 'CropSize',[0.25, 1], 'Flip', 'NumThreads', 12);
    end
else
    if opts.numGpus > 0
        images = vl_imreadjpeg(imfiles, 'Resize', [224, 224], 'Pack', 'CropLocation', 'center', 'CropSize',[1, 1], 'GPU', 'NumThreads', 12);
    else
        images = vl_imreadjpeg(imfiles, 'Resize', [224, 224], 'Pack', 'CropLocation', 'center', 'CropSize',[1, 1], 'NumThreads', 12);
    end
end
images = images{1};
labels = imdb.images.label(1,batch) ;

inputs = {'data', images, 'label', labels} ;

% -------------------------------------------------------------------------

